#!/bin/bash
# Compile the application and run it
javac SeriesModel.java Series.java Main.java
if [ $? -eq 0 ]; then
    echo "Compilation successful. Running application..."
    java Main
else
    echo "Compilation failed."
fi