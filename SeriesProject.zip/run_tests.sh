#!/bin/bash
# Requires junit-platform-console-standalone jar in current dir or provide path as first argument
JAR=${1:-junit-platform-console-standalone-1.9.4.jar}
if [ ! -f "$JAR" ]; then
    echo "JUnit jar not found: $JAR"
    echo "Download it from https://search.maven.org/artifact/org.junit.platform/junit-platform-console-standalone"
    exit 1
fi
javac -cp .:$JAR SeriesTest.java Series.java SeriesModel.java
java -jar "$JAR" -cp . --scan-class-path