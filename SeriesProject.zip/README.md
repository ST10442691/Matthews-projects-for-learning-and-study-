# Series Project

Simple Java console application for managing TV series.

Files:
- SeriesModel.java
- Series.java
- Main.java
- SeriesTest.java (JUnit 5)

How to compile & run (command line):

1. Compile:
   javac SeriesModel.java Series.java Main.java

2. Run:
   java Main

Running tests:
This project does not include Maven/Gradle files. To run the JUnit tests you'll need the junit-platform-console-standalone JAR.
1. Download a JUnit platform standalone jar (e.g. junit-platform-console-standalone-1.9.4.jar).
2. Compile tests:
   javac -cp .:junit-platform-console-standalone-1.9.4.jar SeriesTest.java Series.java SeriesModel.java
   (On Windows replace ':' with ';')
3. Run tests:
   java -jar junit-platform-console-standalone-1.9.4.jar -cp . --scan-class-path

Alternatively, copy the files into your IDE or create a Maven/Gradle project and add JUnit Jupiter.