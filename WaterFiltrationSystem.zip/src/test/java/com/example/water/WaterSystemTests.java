package com.example.water;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WaterSystemTests {

    @Test
    void add_and_find_component() {
        WaterSystemService svc = new WaterSystemService();
        assertTrue(svc.addComponent(new SedimentFilter("C1")));
        assertTrue(svc.findById("C1").isPresent());
    }

    @Test
    void prevent_duplicate_id() {
        WaterSystemService svc = new WaterSystemService();
        assertTrue(svc.addComponent(new CarbonFilter("X1")));
        assertFalse(svc.addComponent(new CarbonFilter("X1")));
    }

    @Test
    void simulate_and_needs_replacement() {
        WaterSystemService svc = new WaterSystemService();
        svc.addComponent(new SedimentFilter("S1")); // interval 90d
        svc.runDays(90);
        assertTrue(svc.findById("S1").get().needsReplacement());
    }

    @Test
    void replace_resets_usage() {
        WaterSystemService svc = new WaterSystemService();
        svc.addComponent(new UVModule("U1"));
        svc.runDays(365);
        assertTrue(svc.findById("U1").get().needsReplacement());
        svc.replaceComponent("U1");
        assertFalse(svc.findById("U1").get().needsReplacement());
        assertEquals(0, svc.findById("U1").get().getDaysUsed());
    }

    @Test
    void report_contains_totals() {
        WaterSystemService svc = new WaterSystemService();
        svc.addComponent(new SedimentFilter("A1"));
        svc.addComponent(new CarbonFilter("A2"));
        String rep = svc.report();
        assertTrue(rep.contains("Total possible replacement cost:"));
    }
}
