package com.example.water;

/**
 * Abstract base for all filtration components.
 * Demonstrates information hiding (private fields) and constructors.
 */
public abstract class Component {
    private final String id;
    private final String name;
    private final int replacementIntervalDays; // days after which component should be replaced
    private int daysUsed; // how many days the component has been used since last replacement

    public Component(String id, String name, int replacementIntervalDays) {
        this.id = id;
        this.name = name;
        this.replacementIntervalDays = replacementIntervalDays;
        this.daysUsed = 0;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getReplacementIntervalDays() { return replacementIntervalDays; }
    public int getDaysUsed() { return daysUsed; }

    // Simulate one day of operation
    public void useOneDay() { this.daysUsed++; }

    // Reset after replacement
    public void replace() { this.daysUsed = 0; }

    // Whether the component should be replaced now
    public boolean needsReplacement() {
        return daysUsed >= replacementIntervalDays;
    }

    // Replacement cost per component type
    public abstract double replacementCost();

    @Override
    public String toString() {
        return String.format("%-6s | %-18s | Interval: %3dd | Used: %3dd | NeedsReplace: %s | Cost: R%.2f",
                id, name, replacementIntervalDays, daysUsed, needsReplacement() ? "YES " : "NO  ", replacementCost());
    }
}
