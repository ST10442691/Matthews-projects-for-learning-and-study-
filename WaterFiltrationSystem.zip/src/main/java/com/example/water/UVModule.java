package com.example.water;

public class UVModule extends Component {
    public UVModule(String id) {
        super(id, "UV Module", 365); // replace yearly
    }

    @Override
    public double replacementCost() { return 1200.00; }
}
