package com.example.water;

import java.util.Scanner;

/**
 * Console UI for the Water Filtration System.
 */
public class WaterApp {
    private final WaterSystemService svc = new WaterSystemService();
    private final Scanner scanner = new Scanner(System.in);

    public void showMenu() {
        System.out.println("============================");
        System.out.println("  Water Filtration System");
        System.out.println("============================");
        System.out.println("1) Add Sediment Filter");
        System.out.println("2) Add Carbon Filter");
        System.out.println("3) Add UV Module");
        System.out.println("4) Simulate days of operation");
        System.out.println("5) Replace component");
        System.out.println("6) Remove component");
        System.out.println("7) View report");
        System.out.println("8) Exit");
        System.out.print("Enter choice: ");
    }

    public void run() {
        while (true) {
            showMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> addComponent("sediment");
                case "2" -> addComponent("carbon");
                case "3" -> addComponent("uv");
                case "4" -> simulate();
                case "5" -> replace();
                case "6" -> remove();
                case "7" -> System.out.println(svc.report());
                case "8" -> { System.out.println("Goodbye"); System.exit(0); }
                default -> System.out.println("Invalid option.");
            }
            System.out.println();
        }
    }

    private void addComponent(String type) {
        System.out.print("Enter component ID: ");
        String id = scanner.nextLine().trim();
        boolean ok = false;
        switch (type) {
            case "sediment" -> ok = svc.addComponent(new SedimentFilter(id));
            case "carbon" -> ok = svc.addComponent(new CarbonFilter(id));
            case "uv" -> ok = svc.addComponent(new UVModule(id));
        }
        System.out.println(ok ? "Component added." : "Component with that ID already exists or invalid.");
    }

    private void simulate() {
        try {
            System.out.print("Enter number of days to simulate: ");
            int days = Integer.parseInt(scanner.nextLine().trim());
            if (days < 0) { System.out.println("Days must be 0 or more."); return; }
            svc.runDays(days);
            System.out.println("Simulation complete. System ran for " + days + " days.");
        } catch (NumberFormatException ex) {
            System.out.println("Invalid number supplied.");
        }
    }

    private void replace() {
        System.out.print("Enter component ID to replace: ");
        String id = scanner.nextLine().trim();
        boolean ok = svc.replaceComponent(id);
        System.out.println(ok ? "Component replaced (usage reset)." : "No component with that ID found.");
    }

    private void remove() {
        System.out.print("Enter component ID to remove: ");
        String id = scanner.nextLine().trim();
        boolean ok = svc.removeById(id);
        System.out.println(ok ? "Component removed." : "No component with that ID found.");
    }

    public static void main(String[] args) { new WaterApp().run(); }
}
