package com.example.water;

import java.util.*;

/**
 * Manages the collection of components (arraylist + loops).
 */
public class WaterSystemService {
    private final List<Component> components = new ArrayList<>();

    public boolean addComponent(Component c) {
        if (c == null) return false;
        if (findById(c.getId()).isPresent()) return false;
        components.add(c);
        return true;
    }

    public Optional<Component> findById(String id) {
        if (id == null) return Optional.empty();
        return components.stream().filter(x -> x.getId().equalsIgnoreCase(id)).findFirst();
    }

    public boolean removeById(String id) {
        return components.removeIf(c -> c.getId().equalsIgnoreCase(id));
    }

    // Simulate running the system for n days (uses loops)
    public void runDays(int days) {
        for (int d = 0; d < days; d++) {
            for (Component c : components) {
                c.useOneDay();
            }
        }
    }

    public boolean replaceComponent(String id) {
        Optional<Component> opt = findById(id);
        if (opt.isEmpty()) return false;
        Component c = opt.get();
        c.replace();
        return true;
    }

    // Produce a console report showing each component and totals
    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append("==== Water Filtration System Report ====" + System.lineSeparator());
        if (components.isEmpty()) {
            sb.append("No components installed." + System.lineSeparator());
            return sb.toString();
        }
        sb.append(String.format("%-6s | %-18s | %-12s | %-10s | %-8s%n", "ID", "Name", "Interval(days)", "Used(days)", "Cost"));
        sb.append("---------------------------------------------------------------------" + System.lineSeparator());
        double totalReplacementCost = 0.0;
        for (Component c : components) {
            sb.append(String.format("%-6s | %-18s | %-12d | %-10d | R%-7.2f%n",
                    c.getId(), c.getName(), c.getReplacementIntervalDays(), c.getDaysUsed(), c.replacementCost()));
            totalReplacementCost += c.replacementCost();
        }
        // how many need replacement now
        long needReplace = components.stream().filter(Component::needsReplacement).count();
        sb.append(System.lineSeparator());
        sb.append("Components needing replacement: " + needReplace + System.lineSeparator());
        sb.append("Total possible replacement cost: R" + String.format("%.2f", totalReplacementCost) + System.lineSeparator());
        return sb.toString();
    }

    // Expose internal list read-only for tests
    public List<Component> allComponents() { return Collections.unmodifiableList(components); }
}
