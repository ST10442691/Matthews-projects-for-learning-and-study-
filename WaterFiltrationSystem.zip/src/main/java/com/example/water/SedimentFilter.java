package com.example.water;

public class SedimentFilter extends Component {
    public SedimentFilter(String id) {
        super(id, "Sediment Filter", 90); // replace every 90 days
    }

    @Override
    public double replacementCost() { return 150.00; }
}
