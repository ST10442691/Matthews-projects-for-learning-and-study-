package com.example.water;

public class CarbonFilter extends Component {
    public CarbonFilter(String id) {
        super(id, "Carbon Filter", 180); // replace every 180 days
    }

    @Override
    public double replacementCost() { return 300.00; }
}
